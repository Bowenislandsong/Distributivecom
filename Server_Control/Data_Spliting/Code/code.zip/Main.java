import com.sun.xml.internal.ws.api.message.ExceptionHasMessage;

import java.io.*;
import java.nio.file.Files;
import org.apache.commons.io.FileUtils;



import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
//compile with javac -cp zip4j_1.3.2.jar *.java
//run with
//java -cp .:zip4j_1.3.2.jar Main <foldernames>

public class Main {


    public static FileAssert fileAssert;
    public static File ResorRootDir;
    public static File CodeRootDir;
    public static Integer Nnode;


    //Traverse to all folder with DFS

    public static void clearEmpDIR(File rootfolder){
        for (File file : rootfolder.listFiles()) {
            if (file.isDirectory())
                file.delete();
        }
    }

    public static void main(String[] args)throws Exception {
        args = new String[3];
        args[0] ="Resourse";
        args[1] ="Code";
        args[2] = "5";
        if (args.length != 3)
            throw new IOException("java -cp .:zip4j_1.3.2.jar Main <Resourcefoldername> <Codingfoldername> <#ofNodes>");
        ResorRootDir = new File(args[0]);
        CodeRootDir = new File(args[1]);
        Nnode = Integer.parseInt(args[2]);
        FileAssert fileAssert = new FileAssert();

        //unzip all the fies in the cod and resource folder, There should not be any zip files inside inner folder
        for (File f:ResorRootDir.listFiles())
            FileAssert.unzip(f,ResorRootDir);
        for (File f:CodeRootDir.listFiles())
            FileAssert.unzip(f,CodeRootDir);


        //this will return num of nodes
        int actualnodes = fileAssert.createDirectoryTree(ResorRootDir);


        for (int i = 0; i<actualnodes;i++){
            File f = new File(String.valueOf(i));
            //include code
            FileUtils.copyDirectory(CodeRootDir, f);
            //Package them into zip
            FileAssert.zipinside(f);
            FileUtils.deleteDirectory(f);
        }

        for (File f:ResorRootDir.listFiles()) {
            if (!f.isDirectory())
                f.delete();
            FileUtils.deleteDirectory(f);
        }

        for (File f:CodeRootDir.listFiles()) {
            if(!f.isDirectory())
                f.delete();
            FileUtils.deleteDirectory(f);
        }

        System.exit(actualnodes);
    }
}
