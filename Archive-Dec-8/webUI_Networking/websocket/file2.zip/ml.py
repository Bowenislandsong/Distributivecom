from zipfile import *
import glob, os
print('2222222')
zip_archive = ZipFile( 'result.zip',"w",ZIP_DEFLATED)
for infile in glob.glob("123.txt"):
	zip_archive.write(infile)